Rem Install referenced libraries

@@../lib/zip_util/install.sql
@@../lib/xlsx_builder/install.sql