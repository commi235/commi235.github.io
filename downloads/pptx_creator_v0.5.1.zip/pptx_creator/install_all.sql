REM Full Installation
SET DEFINE OFF

@@lib/zip_util/install.sql
@@install_main.sql