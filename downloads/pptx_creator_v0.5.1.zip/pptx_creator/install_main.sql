REM Install PPTX Creator
SET DEFINE OFF
@@pptx_creator_pkg.pks
@@pptx_creator_pkg.pkb