PPTX_CREATOR
============
Create PPTX files from a template replacing substitution strings.  

INSTALLATION
------------
Simply run the provided "install_all.sql" file if you want everything installed at once.  
If you have the referenced libraries already you can run "install_main.sql" to install the main package.  
If you just want to install the ZIP_UTIL_PKG then run "/lib/zip_util/install.sql".

DEPENDENCIES
------------
4. ZIP_UTIL_PKG (Included)
5. DBMS_XMLDOM (Oracle XDB)
6. XMLTYPE (Oracle XDB)
