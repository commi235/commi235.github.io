Rem Full installation
SET define OFF

@@install_libs.sql
@@install_main.sql