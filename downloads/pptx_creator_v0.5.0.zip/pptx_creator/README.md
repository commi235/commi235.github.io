PPTX_CREATOR
============
Create pptx files from a template replacing substitution strings.  

INSTALLATION
------------
First install the "Alexandria PL/SQL Utility Library". (http://code.google.com/p/plsql-utils).  
You can either install the full library or just the parts PPTX Creator depends on.
Dependencies on the library are marked with "AX" below.

DEPENDENCIES
------------
1. T_STR_ARRAY (AX)
2. STRING_UTIL_PKG (AX)
3. SQL_UTIL_PKG (AX)
4. ZIP_UTIL_PKG (AX)
5. DBMS_XMLDOM (Oracle XDB)
6. XMLTYPE (Oracle XDB)
